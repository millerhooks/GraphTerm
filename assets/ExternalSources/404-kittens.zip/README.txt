A Pen created at CodePen.io. You can find this one at http://codepen.io/nclud/pen/GJpdVo.

 This is how we pulled off our amazing <a href="http://nclud.com/typekittens">404 page</a>.

